import assert from "node:assert/strict";
import test from "node:test";
import { execFileSync, spawnSync } from "node:child_process";
import { copyFileSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { reviewedTravelDataPaths, isForbiddenTrackedPath, trackedContentFailures } from "./release-check-policy.mjs";

test("only the five reviewed catalog paths bypass the data-directory restriction", () => {
  assert.equal(reviewedTravelDataPaths.length, 5);
  for (const path of reviewedTravelDataPaths) {
    assert.equal(isForbiddenTrackedPath(path), false, path);
    for (const other of [path + ".bak", path.replace(".json", ".sqlite"), "copy/" + path, path.toUpperCase()]) {
      assert.equal(isForbiddenTrackedPath(other), true, other);
    }
  }
  assert.equal(isForbiddenTrackedPath("packages/travel-support/data/china/new-catalog.json"), true);
  assert.equal(isForbiddenTrackedPath("packages/travel-support/data/china/../china/local-food-catalog.json"), true);
});

test("runtime data, backups and credentials remain forbidden", () => {
  for (const path of ["data/workspace.sqlite", "data/backups/backup.json", "apps/server/data/user.json", "runtime/state.json", "secrets/settings.json", ".env", ".env.local", "config/private.key", "workspace.sqlite-wal", "workspace.sqlite-shm"]) {
    assert.equal(isForbiddenTrackedPath(path), true, path);
  }
  assert.equal(isForbiddenTrackedPath(".env.example"), false);
  assert.equal(isForbiddenTrackedPath("apps/server/src/index.ts"), false);
});

test("reviewed catalogs still receive every existing sensitive-content check", () => {
  for (const path of reviewedTravelDataPaths) {
    assert.deepEqual(trackedContentFailures(path, '{"sources":[]}'), []);
    for (const content of ["GOOGLE_MAPS_API_KEY=synthetic-fixture", "123456789:" + "x".repeat(30), "-----BEGIN PRIVATE KEY-----"]) {
      assert.equal(trackedContentFailures(path, content).length, 1);
      assert.equal(trackedContentFailures(path, content).length, 1, "repeated scans must not skip matches");
    }
  }
});

test("actual release preflight admits the catalogs but rejects extra data, secrets and invalid JSON", () => {
  const root = mkdtempSync(join(tmpdir(), "landi-release-data-policy-"));
  const write = (path, content) => { mkdirSync(dirname(join(root, path)), { recursive: true }); writeFileSync(join(root, path), content); };
  const run = () => spawnSync(process.execPath, [join(root, "scripts/release-check.mjs")], { cwd: root, encoding: "utf8" });
  try {
    mkdirSync(join(root, "scripts"));
    for (const name of ["release-check.mjs", "release-check-policy.mjs"]) copyFileSync(new URL(name, import.meta.url), join(root, "scripts", name));
    write("package.json", JSON.stringify({ version: "0.1.0", packageManager: "pnpm@11.20.0", scripts: Object.fromEntries(["build", "typecheck", "test", "test:browser", "release:check"].map(key => [key, "fixture"])) }));
    for (const [index, path] of ["apps/server", "apps/web", "packages/agent-adapters", "packages/connectors", "packages/core", "packages/storage", "packages/travel-support"].entries()) {
      write(path + "/package.json", JSON.stringify({ name: `fixture-${index}`, version: "0.1.0", private: true }));
    }
    write(".env.example", ["C_ASSISTANT_RUNTIME", "GOOGLE_MAPS_API_KEY", "C_ASSISTANT_HOST", "C_ASSISTANT_PORT", "C_ASSISTANT_DATA_PATH"].map(key => key + "=").join("\n"));
    for (const path of reviewedTravelDataPaths) write(path, '{"sources":[]}');
    execFileSync("git", ["init", "--quiet"], { cwd: root });
    execFileSync("git", ["add", "--", "packages/travel-support/data"], { cwd: root });
    let result = run();
    assert.equal(result.status, 0, result.stderr);

    const extra = "packages/travel-support/data/user.json";
    write(extra, "{}");
    execFileSync("git", ["add", "--", extra], { cwd: root });
    result = run();
    assert.equal(result.status, 1);
    assert.match(result.stderr, /Sensitive or runtime-only path/);
    execFileSync("git", ["rm", "--cached", "--quiet", "--", extra], { cwd: root });
    rmSync(join(root, extra));

    write(reviewedTravelDataPaths[0], JSON.stringify({ note: "-----BEGIN PRIVATE KEY-----" }));
    result = run();
    assert.equal(result.status, 1);
    assert.match(result.stderr, /A private key may be tracked/);

    write(reviewedTravelDataPaths[0], "invalid-json-fixture");
    result = run();
    assert.equal(result.status, 1);
    assert.match(result.stderr, /missing or invalid JSON/);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
